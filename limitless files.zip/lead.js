// Vercel serverless function — receives quote-form submissions from index.html
// and forwards them to your GoHighLevel Inbound Webhook.
// The GoHighLevel URL is read from the GHL_WEBHOOK_URL environment variable,
// so it never appears in your code or your public repo.

export default async function handler(req, res) {
  // Only allow POST (the form sends POST).
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const webhookUrl = process.env.GHL_WEBHOOK_URL;
  if (!webhookUrl) {
    // The environment variable hasn't been set in Vercel yet.
    res.status(500).json({ error: 'Lead endpoint is not configured.' });
    return;
  }

  try {
    const upstream = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body || {}),
    });

    if (!upstream.ok) {
      res.status(502).json({ error: 'The lead service rejected the request.' });
      return;
    }

    res.status(200).json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to forward the lead.' });
  }
}
